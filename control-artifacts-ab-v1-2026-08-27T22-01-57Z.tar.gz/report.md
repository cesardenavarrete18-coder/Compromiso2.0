# A/B v1 — control

- A/B Run ID: `ab-v1-2026-08-27T22-01-57Z`
- Arm Run ID: `ab-v1-2026-08-27T22-01-57Z-control-2026-08-27T22-06-14-476Z`
- Arm: `control`
- Source commit: `79f1a9ef537c103efbe6a58082191501e3622e0c`
- Canonical grader: `151158dd6c65a410daf95a0dc6d9e7520d970d45ccfb58f1864e302f20dea203`
- Input manifest: `e785040e009655367d618512f42a51d9007dda8a33e25ccc48e15af5c8f72b3b`
- Model: `gpt-4.1-mini-2025-04-14`
- Vector Store: `vs_6a80740821c081918bc10552428e6249`

## Resultado

- Score oficial: **63.53**
- Normalized existing capabilities: **89.22**
- Official PASS: **0**
- Official FAIL: **100**

| Grader | Score |
|---|---:|
| extraction | 77 |
| qualification | 62 |
| temperature | 0 |
| handoff | 0 |
| commercial_profile | 0 |
| conversation_status | 0 |
| next_action | 68.67 |
| conversational_compliance | 93.17 |
| grounding | 98 |
| hallucinations | 100 |
| privacy | 100 |

Este brazo es contemporáneo y no sobrescribe el Baseline v2 histórico.
