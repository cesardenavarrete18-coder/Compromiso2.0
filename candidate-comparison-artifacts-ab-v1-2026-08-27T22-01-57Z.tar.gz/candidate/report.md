# A/B v1 — candidate

- A/B Run ID: `ab-v1-2026-08-27T22-01-57Z`
- Arm Run ID: `ab-v1-2026-08-27T22-01-57Z-candidate-2026-08-28T00-31-37-514Z`
- Arm: `candidate`
- Source commit: `29338872d1660225cfd24fad259941f224b576a7`
- Canonical grader: `151158dd6c65a410daf95a0dc6d9e7520d970d45ccfb58f1864e302f20dea203`
- Input manifest: `e785040e009655367d618512f42a51d9007dda8a33e25ccc48e15af5c8f72b3b`
- Model: `gpt-4.1-mini-2025-04-14`
- Vector Store: `vs_6a80740821c081918bc10552428e6249`

## Resultado

- Score oficial: **80.77**
- Normalized existing capabilities: **80.77**
- Official PASS: **23**
- Official FAIL: **77**

| Grader | Score |
|---|---:|
| extraction | 88 |
| qualification | 79 |
| temperature | 73 |
| handoff | 45 |
| commercial_profile | 28 |
| conversation_status | 55 |
| next_action | 77 |
| conversational_compliance | 99.67 |
| grounding | 99 |
| hallucinations | 100 |
| privacy | 100 |

Este brazo es contemporáneo y no sobrescribe el Baseline v2 histórico.
