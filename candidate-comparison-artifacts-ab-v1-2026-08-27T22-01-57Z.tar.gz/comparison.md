# Grupo Sur AI — comparación A/B v1

| Resultado pareado | Casos |
|---|---:|
| Mejorados | 92 |
| Regresionados | 5 |
| Sin cambio | 3 |

- Critical failures eliminados: **10**
- Critical failures nuevos: **3**
- Control score: **63.53**
- Candidate score: **80.77**

El Baseline v2 histórico 63.31 / 88.76 permanece separado y no fue sobrescrito.
